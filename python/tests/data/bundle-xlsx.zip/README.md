# OECD Creditor Reporting System (CRS), 2020–2023

Data downloaded from the Development Finance Observatory (DFO), prepared on 20 October 2026.

4 rows · 1 variable · 1 provider, 1 recipient · 2020–2023 · Unit: US Dollar

## Files

| File | Contents |
| --- | --- |
| `data/oecd-creditor-reporting-system.xlsx` | The data. One row per observation. |
| `data/codes.csv` | The plain name of every code in the data, such as `country/DEU` for Germany |
| `SOURCES.md` | Who publishes the data, its licence, and each step the DFO applied |
| `CITATION.cff` | The citation, in a format reference managers read |
| `datapackage.json` | A machine-readable description (Frictionless Data Package 2.0) |

## Variables

The file holds 1 variable:

- Official development assistance gross disbursements for basic health care (standard grant, core support to non-governmental organisations, other private bodies, public-private partnerships, and research institutes)

## Columns

| Column | Meaning |
| --- | --- |
| `stat_var` | The variable measured. Names are in `data/codes.csv`. |
| `financingProvider` | The provider the value flows from. Names are in `data/codes.csv`. |
| `financingProvider_label` | The name of the provider. |
| `financingProvider_party_kind` | Whether the provider is a `party` (a country, territory or organisation), a `total` that holds other providers' figures, or a `residual` no other provider holds. A sum over providers that includes a total counts its members twice. Leaving totals out does not make every sum exact: two parties can report the same money, such as a fund and the organisation that runs it. |
| `financingRecipient` | The recipient the value flows to. Names are in `data/codes.csv`. |
| `financingRecipient_label` | The name of the recipient. |
| `financingRecipient_party_kind` | Whether the recipient is a `party` (a country, territory or organisation), a `total` that holds other recipients' figures, or a `residual` no other recipient holds. A sum over recipients that includes a total counts its members twice. Leaving totals out does not make every sum exact: two parties can report the same money, such as a fund and the organisation that runs it. |
| `crsCooperationModality` | The modality of the variable, as a code. Names are in `data/codes.csv`. |
| `crsCooperationModality_label` | The modality of the variable, in words. |
| `crsPurpose` | The sector of the variable, as a code. Names are in `data/codes.csv`. |
| `crsPurpose_label` | The sector of the variable, in words. |
| `crsTypeOfFinance` | The instrument of the variable, as a code. Names are in `data/codes.csv`. |
| `crsTypeOfFinance_label` | The instrument of the variable, in words. |
| `crsTypeOfFlow` | The flow of the variable, as a code. Names are in `data/codes.csv`. |
| `crsTypeOfFlow_label` | The flow of the variable, in words. |
| `time_period` | The period the value refers to. |
| `value` | The observed value, in the unit named in `unit`. |
| `unit` | The unit of `value`. Names are in `data/codes.csv`. |
| `unit_label` | The name of the unit, such as "Constant 2023 US dollars". |
| `currency` | The ISO 4217 code of the currency `value` is in. |
| `price_basis` | Whether `value` is in `current` or `constant` prices. |
| `base_year` | The year whose prices a `constant` value is in. Empty in this file. |
| `measurementMethod` | How the source measured the value. Empty in this file. |
| `measurementMethod_label` | The name of the measurement method, empty when the graph holds no name beyond the method's code. Empty in this file. |
| `provenance` | The source dataset of the row. Names are in `data/codes.csv`. |
| `provenance_label` | The name of the source dataset. |

## Licence

Organisation for Economic Co-operation and Development (OECD) publishes OECD Creditor Reporting System (CRS) under OECD Terms and Conditions (https://www.oecd.org/en/about/terms-conditions.html). Those terms govern reuse of this data. The DFO adds no terms of its own.

## How to cite

Cite the source as its publisher asks:

> OECD (2026), Creditor Reporting System (CRS), OECD Data Explorer, https://webfs-dcd.oecd.org/files/dotStat/DSD_CRS/CRS.parquet (accessed on 2026-10-15)

and this extract:

> Development Finance Observatory (2026). OECD Creditor Reporting System (CRS), 2020–2023 [dataset], version bf2421. https://dfo-dev-website-staging-zms5lj4zhq-nn.a.run.app/data?spec=spec_cb5baa4161de718f18583060674dbca6&v=cv_bf242138f8d0a892c97da9373d1626f4

## Get this data again

No API key is needed.

- On the website: https://dfo-dev-website-staging-zms5lj4zhq-nn.a.run.app/data?spec=spec_cb5baa4161de718f18583060674dbca6&v=cv_bf242138f8d0a892c97da9373d1626f4. The link keeps working, and this version's rows stay available as Parquet.
- This exact version: `curl "https://dfo-dev-website-staging-zms5lj4zhq-nn.a.run.app/api/datasets/spec_cb5baa4161de718f18583060674dbca6/cv_bf242138f8d0a892c97da9373d1626f4"` returns fresh download links. Files fetched only through the API are kept for 30 days from when they were made.
- The latest data for the same definition: `curl "https://dfo-dev-website-staging-zms5lj4zhq-nn.a.run.app/api/datasets/spec_cb5baa4161de718f18583060674dbca6?format=xlsx&bundle=true"`.
- To rebuild it yourself, save the request body below as `request.json` and run `curl -X POST -H "Content-Type: application/json" -d @request.json https://dfo-dev-website-staging-zms5lj4zhq-nn.a.run.app/api/datasets`.

```json
{"schema_version": 1, "input": {"kind": "spec_id", "spec_id": "spec_cb5baa4161de718f18583060674dbca6", "definition": {"schema_version": 1, "spec_id": "spec_cb5baa4161de718f18583060674dbca6", "identity": {"shape": {"kind": "statvar_schema", "stat_type": "measuredValue", "population_type": "FinancialFlow", "measured_property": "amount", "measurement_qualifier": "Nominal"}, "slots": [{"binding": {"state": "unbound"}, "property": "crsCooperationModality"}, {"binding": {"ref": "CRSPurposeCode12220", "state": "value"}, "property": "crsPurpose"}, {"binding": {"state": "unbound"}, "property": "crsTypeOfFinance"}, {"binding": {"ref": "CRSTypeOfFlow10", "state": "value"}, "property": "crsTypeOfFlow"}, {"binding": {"ref": "Disbursement", "state": "value"}, "property": "financialFlowType"}, {"binding": {"ref": "Gross", "state": "value"}, "property": "nettingBasis"}], "entities": {"origin": ["country/DEU"], "destination": ["country/NGA"]}, "identity_version": "spec1", "requested_window": {"kind": "range", "end_year": 2023, "start_year": 2020}}}}, "options": {"format": "xlsx", "bundle": true, "without_party_totals": false}}
```

## Open the data

- Spreadsheet: open the XLSX file in Excel, Numbers or Google Sheets. Look up codes in `data/codes.csv`.
- Python: `pandas.read_excel("data/oecd-creditor-reporting-system.xlsx")`.
- R: `readxl::read_excel("data/oecd-creditor-reporting-system.xlsx")`.

## About the Development Finance Observatory

The Development Finance Observatory brings development finance data together in one place. It is an initiative of ONE Data, with support from the Rockefeller Foundation. Find more data at https://dfo-dev-website-staging-zms5lj4zhq-nn.a.run.app. Questions or problems: data@one.org.

## Version

Version bf2421 (content version cv_bf242138f8d0a892c97da9373d1626f4), dataset definition spec_cb5baa4161de718f18583060674dbca6, prepared 2026-10-20. One version always holds the same numbers.
