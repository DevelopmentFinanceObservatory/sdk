# Sources

Who publishes the data in this download, the terms for its reuse, and each step the DFO applied, as the DFO catalogue recorded them when this version was first prepared.

## OECD Creditor Reporting System (CRS)

The Creditor Reporting System (CRS) is the OECD Development Assistance Committee's activity-level database of development finance. Each record is a project, programme or contribution reported by a bilateral provider, a multilateral organisation or a private foundation, with its recipient, sector and purpose, channel of delivery, aid type, and commitment and disbursement amounts. It covers ODA, other official flows, private sector instruments and private philanthropy, and is the source for any breakdown by sector, channel or project.

- Publisher: Organisation for Economic Co-operation and Development (OECD)
- Source page: https://data-explorer.oecd.org/vis?tm=crs&pg=0&snb=30&df[ds]=dsDisseminateFinalDMZ&df[id]=DSD_CRS%40DF_CRS&df[ag]=OECD.DCD.FSD&df[vs]=1.6&isAvailabilityDisabled=false&page=0
- Raw data: https://webfs-dcd.oecd.org/files/dotStat/DSD_CRS/CRS.parquet
- Licence: OECD Terms and Conditions (https://www.oecd.org/en/about/terms-conditions.html)
- Updates: Quarterly
- Last update: 2026-10-15
- Years covered: 1973-2024
- Granularity: Annual, by provider and recipient
- Currency: USD

### How the publisher asks to be cited

> OECD (2026), Creditor Reporting System (CRS), OECD Data Explorer, https://webfs-dcd.oecd.org/files/dotStat/DSD_CRS/CRS.parquet (accessed on 2026-10-15)

### What the DFO did

1. Download the source data

   The complete CRS file is downloaded from the OECD each time the pipeline runs, and replaces the previous copy, so the data reflects the OECD's latest release.

2. Exclude the partial preliminary year

   Before each full release, the OECD publishes preliminary data for the year that release covers, as reporters submit it. Until then, that year is partial, so the pipeline excludes it. Support for partial years is in development. Partial years will be marked incomplete, so they don't lead to incorrect or confusing analyses.

3. Exclude donor core contributions to multilaterals

   The OECD instructs that donor core contributions to multilateral organisations, reported as ordinary CRS rows flagged `bi_multi = 2`, are excluded to compute bilateral flows. These contributions are already reported in Members' Total Use of the Multilateral System, so keeping them would double count.

4. Standardise providers and recipients

   Provider and recipient codes are standardised to Data Commons IDs used across the platform, so data can be compared across datasets.

5. Select dimensions

   Every figure is reported against the year, the provider and the recipient, and four dimensions from the CRS: type of flow, co-operation modality, type of finance and purpose code. The CRS describes each activity in far more detail than this, including project titles, descriptions, channels and policy markers, none of which is carried through.

6. Aggregate totals

   Activities sharing the same year, provider, recipient and dimensions are summed. Commitments, disbursements, net disbursements and grant equivalents are each aggregated as separate measures. Every figure is reported in US dollars at current prices.

### Version history

- 2026-10-15: Partial preliminary year excluded
  - Changed: The partial preliminary year published ahead of the next full release is excluded.
- 2026-10-14: First release
  - Added: Commitments, gross and net disbursements, and grant equivalents by donor, recipient, flow type, finance type, modality and purpose, at current US dollar prices. Covers ODA, other official flows, private development finance and private sector instruments.

### Full documentation

- https://dfo-dev-website-staging-zms5lj4zhq-nn.a.run.app/data/sources/provenance/OECDCreditorReportingSystem
- https://dfo-dev-website-staging-zms5lj4zhq-nn.a.run.app/api/graph/documentation/provenance/OECDCreditorReportingSystem
